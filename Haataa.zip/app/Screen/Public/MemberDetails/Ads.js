const Entry = [
    {
        title: 'Luxury Home Near New York',
        price: '$4,850,000',
        location: 'New York, US',
        date: '25 Apr',
        image: 'https://www.furniturestorelosangeles.com/media/catalog/product/cache/1/image/9df78eab33525d08d6e5fb8d27136e95/a/c/acp_j2020.jpg',
    },
    {
        title: '60 inch LED TV',
        price: '$10,000',
        location: 'New York, US',
        date: '25 Apr',
        image: 'https://static.digit.in/default/6651fea04f52a58009bb82380dd8ee7df6e32652.jpeg',
    },
    
    {
        title: 'Looking for IOS Developer',
        price: '$4,850,000',
        location: 'Washington, US',
        date: '25 Apr',
        image: 'https://4qr7k2a2xza2vctux33bisalkw-wpengine.netdna-ssl.com/wp-content/uploads/2015/07/Full-time-hiring-8.2015-07-700x699.png',
    },
    {
        title: 'i10 Santro',
        price: '$4,850,000',
        location: 'New York, US',
        date: '25 Apr',
        image: 'https://houseofhargrove.com/wp-content/uploads/2017/10/Beautiful-Exteriors1.jpg',
    },

]

export default Entry