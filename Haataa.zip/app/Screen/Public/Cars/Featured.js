const Entry = [

    {
        title: 'Car Engine 01whrsp',
        price: '$2,00,000',
        image: 'https://cdn.trangcongnghe.com/uploads/posts/2017-07/can-canh-siecircu-xe-audi-r8-spyder-v10-plus-do-ruc-bang-xuong-bang-thit_1.jpg',
    },
    {
        title: 'Car Clutch -3vur 11mn',
        price: '$2,00,000',
        image: 'https://www.furniturestorelosangeles.com/media/catalog/product/cache/1/image/9df78eab33525d08d6e5fb8d27136e95/a/c/acp_j2020.jpg',
    },
    {
        title: 'Car Engine 01whrsp',
        price: '$2,00,000',
        image: 'https://cdn.trangcongnghe.com/uploads/posts/2017-07/can-canh-siecircu-xe-audi-r8-spyder-v10-plus-do-ruc-bang-xuong-bang-thit_1.jpg',
    },
    {
        title: 'Car Clutch -3vur 11mn',
        price: '$2,00,000',
        image: 'https://www.furniturestorelosangeles.com/media/catalog/product/cache/1/image/9df78eab33525d08d6e5fb8d27136e95/a/c/acp_j2020.jpg',
    },
    {
        title: 'Car Engine 01whrsp',
        price: '$2,00,000',
        image: 'https://cdn.trangcongnghe.com/uploads/posts/2017-07/can-canh-siecircu-xe-audi-r8-spyder-v10-plus-do-ruc-bang-xuong-bang-thit_1.jpg',
    },
    {
        title: 'Car Clutch -3vur 11mn',
        price: '$2,00,000',
        image: 'https://www.furniturestorelosangeles.com/media/catalog/product/cache/1/image/9df78eab33525d08d6e5fb8d27136e95/a/c/acp_j2020.jpg',
    },
]

export default Entry