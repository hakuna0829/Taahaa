const Entry = [

    {
        title: 'Orlando Vacation Packages For This Summer',
        location: 'Orlando, USA',
        description:'Enjoy all all the attraction of orlando ',
        image: 'https://www.costcotravel.com/content/_legacy/shared/images/vacationPackages/package/FLAMCOCABANAVBUOR20190301/FLAMCOCABANAVBUOR20190301_F_1.jpg',
    },
    {
        title: 'National Park Adventure in Las Vegas',
        location: 'Las Vegas, USA',
        description:'Enjoy all all the attraction of orlando ',
        image: 'https://www.costcotravel.com/content/_legacy/shared/images/vacationPackages/package/FLAMCOSVRUOR20140117/FLAMCOSVRUOR20140117_F_1.jpg',
    },
    {
        title: 'Orlando Vacation Packages For This Summer',
        location: 'Orlando, USA',
        description:'Enjoy all all the attraction of orlando ',
        image: 'https://www.costcotravel.com/content/_legacy/shared/images/vacationPackages/package/FLAMCOCABANAVBUOR20190301/FLAMCOCABANAVBUOR20190301_F_1.jpg',
    },
    
    {
        title: 'National Park Adventure in Las Vegas',
        location: 'Las Vegas, USA',
        description:'Enjoy all all the attraction of orlando ',
        image: 'https://www.costcotravel.com/content/_legacy/shared/images/vacationPackages/package/FLAMCOSVRUOR20140117/FLAMCOSVRUOR20140117_F_1.jpg',
    },
    {
        title: 'National Park Adventure in Las Vegas',
        location: 'Las Vegas, USA',
        description:'Enjoy all all the attraction of orlando ',
        image: 'https://www.costcotravel.com/content/_legacy/shared/images/vacationPackages/package/FLAMCOSVRUOR20140117/FLAMCOSVRUOR20140117_F_1.jpg',
    }
]

export default Entry