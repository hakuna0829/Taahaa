const Entry = [

    {
        label: 'Company',
        value: 'Audi',
    },
    {
        label: 'Model',
        value: 'R8',
    },
    {
        label: 'Fuel',
        value: 'Petro',
    },
    {
        label: 'Year',
        value: '2018',
    },
    {
        label: 'Color',
        value: 'Cherry Red',
    },
    {
        label: 'Reference ID',
        value: '#CA01452',
    },
    
]

export default Entry