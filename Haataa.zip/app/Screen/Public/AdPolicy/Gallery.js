const Entry = [

    {
        title: 'Audi R8',
        date: '25 Aug',
        location: 'Bristol, England',
        image: 'https://i1.wp.com/lvttclub.com/wp-content/uploads/2017/10/AUDITTS-3658_6.jpg?fit=1280%2C842',
    },
    {
        title: 'Audi R8',
        location: 'Bristol, England',
        image: 'http://carindia.in/wp-content/uploads/2015/09/Audi-RS-6-Avant-1-web.jpg',
    },
    {
        title: 'Audi R8',
        location: 'Bristol, England',
        image: 'https://photos.donedeal.ie/ddimg/YzE4MWI5MzJlNTg1OTViOGY3NTExMTgwODIzMTFjMGUM_zPiYevRoWzkhVWw_u_saHR0cDovL3MzLWV1LXdlc3QtMS5hbWF6b25hd3MuY29tL2RvbmVkZWFsLmllLXBob3Rvcy9waG90b18xMDM2ODUxMTZ8fHx8fHw2MDB4NDUwfHx8fHw=.jpeg',
    },
    {
        title: 'Audi R8',
        location: 'Bristol, England',
        image: 'https://www.audi.cl/media/Model_Gallery_DetailImage_Image_XSmall_Component/43560-342765_50393-image-xsmall/dh-786-b05066/c149165f/1493327800/nuevo-audi-a5-sportback.jpg',
    },
    {
        title: 'Audi R8',
        location: 'Bristol, England',
        image: 'https://st.automobilemag.com/uploads/sites/11/2015/06/2015-Audi-A3-Cabriolet-rear-three-quarter-view-in-motion-2.jpg',
    },
        
]

export default Entry