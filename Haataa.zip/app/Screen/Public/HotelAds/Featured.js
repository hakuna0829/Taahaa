const Entry = [

    {
        title: 'FabHotel Kelvish New Delhi Airport',
        location:'Gurugram, New Delhi',
        image: 'https://www.hotel-scoop.com/wp-content/uploads/2018/08/IMG_3123-667x500.jpg',
    },
    {
        title: 'FabHotel Kelvish New Delhi Airport',
        location:'Gurugram, New Delhi',
        image: 'https://www.hotel-scoop.com/wp-content/uploads/2018/08/IMG_3123-667x500.jpg',
    },
    {
        title: 'FabHotel Kelvish New Delhi Airport',
        location:'Gurugram, New Delhi',
        image: 'https://www.hotel-scoop.com/wp-content/uploads/2018/08/IMG_3123-667x500.jpg',
    },
    {
        title: 'FabHotel Kelvish New Delhi Airport',
        location:'Gurugram, New Delhi',
        image: 'https://www.hotel-scoop.com/wp-content/uploads/2018/08/IMG_3123-667x500.jpg',
    },
    {
        title: 'FabHotel Kelvish New Delhi Airport',
        location:'Gurugram, New Delhi',
        image: 'https://www.hotel-scoop.com/wp-content/uploads/2018/08/IMG_3123-667x500.jpg',
    },
    {
        title: 'FabHotel Kelvish New Delhi Airport',
        location:'Gurugram, New Delhi',
        image: 'https://www.hotel-scoop.com/wp-content/uploads/2018/08/IMG_3123-667x500.jpg',
    },
    
]

export default Entry