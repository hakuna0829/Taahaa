const Entry = [

    {
        title: 'Redmi Note 6 Pro (Rose Gold, 64 GB)',
        price:'₹11,999',
        spec: '4 GB RAM | 64 GB ROM | Expandable Upto 256 GB',
        display: '15.9 cm (6.26 inch)FHD + Display',
        camera: '12MP + 5MP | 20MP Dual Front Camera',
        image: 'https://www.android.com/static/2016/img/devices/phones/htc-10/transparent/htc-10-02_1x.png',
    },
    {
        title: 'Samsung Galaxy S8 ( 64 GB )',
        price:'₹11,999',
        spec: '4 GB RAM | 64 GB ROM | Expandable Upto 256 GB',
        display: '15.9 cm (6.26 inch)FHD + Display',
        camera: '12MP + 5MP | 20MP Dual Front Camera',
        image: 'https://www.android.com/static/2016/img/devices/phones/samsung-galaxy-s8/front-black_1x.png',
    },
    {
        title: 'Redmi Note 6 Pro (Rose Gold, 64 GB)',
        price:'₹11,999',
        spec: '4 GB RAM | 64 GB ROM | Expandable Upto 256 GB',
        display: '15.9 cm (6.26 inch)FHD + Display',
        camera: '12MP + 5MP | 20MP Dual Front Camera',
        image: 'https://www.android.com/static/2016/img/devices/phones/htc-10/transparent/htc-10-02_1x.png',
    },
    {
        title: 'Samsung Galaxy S8 ( 64 GB )',
        price:'₹11,999',
        spec: '4 GB RAM | 64 GB ROM | Expandable Upto 256 GB',
        display: '15.9 cm (6.26 inch)FHD + Display',
        camera: '12MP + 5MP | 20MP Dual Front Camera',
        image: 'https://www.android.com/static/2016/img/devices/phones/samsung-galaxy-s8/front-black_1x.png',
    },
    {
        title: 'Redmi Note 6 Pro (Rose Gold, 64 GB)',
        price:'₹11,999',
        spec: '4 GB RAM | 64 GB ROM | Expandable Upto 256 GB',
        display: '15.9 cm (6.26 inch)FHD + Display',
        camera: '12MP + 5MP | 20MP Dual Front Camera',
        image: 'https://www.android.com/static/2016/img/devices/phones/htc-10/transparent/htc-10-02_1x.png',
    },
    {
        title: 'Samsung Galaxy S8 ( 64 GB )',
        price:'₹11,999',
        spec: '4 GB RAM | 64 GB ROM | Expandable Upto 256 GB',
        display: '15.9 cm (6.26 inch)FHD + Display',
        camera: '12MP + 5MP | 20MP Dual Front Camera',
        image: 'https://www.android.com/static/2016/img/devices/phones/samsung-galaxy-s8/front-black_1x.png',
    },
    
]

export default Entry