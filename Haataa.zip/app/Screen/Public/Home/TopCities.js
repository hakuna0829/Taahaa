const Entry = [

    {
        location: 'London',
        count: '130',
        image: 'https://cdn.londonandpartners.com/visit/london-organisations/houses-of-parliament/63950-640x360-london-icons2-640.jpg',
    },
    {
        location: 'Manchester',
        count: '110',
        image: 'https://www.visitbritain.com/sites/default/files/consumer_destinations/teaser_images/manchester_town_hall.jpg',
    },
    {
        location: 'Birmingham',
        count: '50',
        image: 'http://vle.wolvcoll.ac.uk/reporter/wp-content/uploads/2016/06/New-StMetro-EZ.jpg',
    },
    {
        location: 'Bristol',
        count: '48',
        image: 'http://soton.pl/wp-content/uploads/2017/01/7858490506_26a7bb0933_b.jpg',
    },
    {
        location: 'Liverpool',
        count: '80',
        image: 'https://media-cdn.tripadvisor.com/media/photo-s/12/1e/c7/71/mann-island-pier-head.jpg',
    },
    {
        location: 'Edinburgh',
        count: '30',
        image: 'https://media-cdn.tripadvisor.com/media/photo-s/0f/4a/fe/6e/edinburgh-from-calton.jpg',
    },
    
]

export default Entry