const Entry = [

    {
        name: 'Michael',
        location: 'Boston',
        image: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&h=300',
    },
    {
        name: 'Nick',
        location: 'San Franciso',
        image: 'https://images.pexels.com/photos/713520/pexels-photo-713520.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=300',
    },
    {
        name: 'Jessica',
        location: 'New York',
        image: 'https://images.pexels.com/photos/38554/girl-people-landscape-sun-38554.jpeg?auto=compress&cs=tinysrgb&h=300',
    },
    {
        name: 'Robert De Niro',
        location: 'Chicago',
        image: 'https://images.pexels.com/photos/874158/pexels-photo-874158.jpeg?auto=compress&cs=tinysrgb&h=300',
    },
    {
        name: 'Ainsley',
        location: 'New Orleans',
        image: 'https://images.pexels.com/photos/324658/pexels-photo-324658.jpeg?auto=compress&cs=tinysrgb&h=300',
    },
    {
        name: 'Russell Crowe',
        location: 'Los Angeles',
        image: 'https://images.pexels.com/photos/894723/pexels-photo-894723.jpeg?auto=compress&cs=tinysrgb&h=300',
    },
    
]

export default Entry