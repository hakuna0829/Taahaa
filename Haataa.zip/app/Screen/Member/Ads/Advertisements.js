const Entry = [

    {
        title: 'Audi R8',
        location: 'New York, US',
        price: '$650',
        category: 'Automobile',
        subcategory: 'Cars',
        image: 'https://cdn.trangcongnghe.com/uploads/posts/2017-07/can-canh-siecircu-xe-audi-r8-spyder-v10-plus-do-ruc-bang-xuong-bang-thit_1.jpg',
    },
    {
        title: 'Sofa Set for Sale',
        location: 'Los Angeles, US',
        price:'$112',
        category: 'Household',
        subcategory: 'Furnitures',
        image: 'https://www.furniturestorelosangeles.com/media/catalog/product/cache/1/image/9df78eab33525d08d6e5fb8d27136e95/a/c/acp_j2020.jpg',
    },
    {
        title: '60 inch LED TV',
        location: 'California, US',
        price:'$45',
        category: 'Eletronics',
        subcategory: 'Television',
        image: 'https://static.digit.in/default/6651fea04f52a58009bb82380dd8ee7df6e32652.jpeg',
    },
    
    {
        title: 'Looking for IOS Developer',
        location: 'Washington, D.C',
        price:'$650',
        category: 'Jobs',
        subcategory: 'Software',
        image: 'https://4qr7k2a2xza2vctux33bisalkw-wpengine.netdna-ssl.com/wp-content/uploads/2015/07/Full-time-hiring-8.2015-07-700x699.png',
    },
    {
        title: 'Home for Rent',
        location: 'Brooklyn, New York',
        price:'$---',
        category: 'Real Estate',
        subcategory: 'Buy',
        image: 'https://houseofhargrove.com/wp-content/uploads/2017/10/Beautiful-Exteriors1.jpg',
    },
]

export default Entry