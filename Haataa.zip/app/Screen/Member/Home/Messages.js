const Entry = [
    {
        name: 'Michael',
        desc: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
        image: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&h=200',
        date: '1 hr ago',
    },
    {
        name: 'Nick',
        desc: 'Nunc sodales vitae ligula eu hendrerit.',
        image: 'https://images.pexels.com/photos/713520/pexels-photo-713520.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=200',
        date: 'yesterday',
    },
    {
        name: 'Ainsley',
        desc: 'Donec in magna sodales, semper urna et, gravida enim.',
        image: 'https://images.pexels.com/photos/324658/pexels-photo-324658.jpeg?auto=compress&cs=tinysrgb&h=200',
        date: '15 Aug 2018',
    },
    
]

export default Entry