const Entry = [
    {
        name: 'Michael',
        desc: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
        image: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&h=300',
        date: '1 hr ago',
    },
    {
        name: 'Nick',
        desc: 'Nunc sodales vitae ligula eu hendrerit.',
        image: 'https://images.pexels.com/photos/713520/pexels-photo-713520.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=300',
        date: 'yesterday',
    },
    {
        name: 'Jessica',
        desc: 'Donec in magna sodales, semper urna et, gravida enim.',
        image: 'https://images.pexels.com/photos/38554/girl-people-landscape-sun-38554.jpeg?auto=compress&cs=tinysrgb&h=300',
        date: '15 Aug 2018',
    },
    {
        name: 'Robert De Niro',
        desc: 'Etiam sagittis turpis a ligula finibus dignissim.',
        image: 'https://images.pexels.com/photos/874158/pexels-photo-874158.jpeg?auto=compress&cs=tinysrgb&h=300',
        date: '13 Aug 2018',
    },
    {
        name: 'Ainsley',
        desc: 'Fusce fermentum diam sed vulputate fringilla.',
        image: 'https://images.pexels.com/photos/324658/pexels-photo-324658.jpeg?auto=compress&cs=tinysrgb&h=300',
        date: '28 Jul 2018',
    },
    {
        name: 'Russell Crowe',
        desc: 'Mauris dolor magna, sodales et finibus nec, feugiat nec enim.',
        image: 'https://images.pexels.com/photos/894723/pexels-photo-894723.jpeg?auto=compress&cs=tinysrgb&h=300',
        date: '15 Jul 2018',
    },
    {
        name: 'Jessica',
        desc: 'Donec in magna sodales, semper urna et, gravida enim.',
        image: 'https://images.pexels.com/photos/38554/girl-people-landscape-sun-38554.jpeg?auto=compress&cs=tinysrgb&h=300',
        date: '15 Aug 2018',
    },
    {
        name: 'Robert De Niro',
        desc: 'Etiam sagittis turpis a ligula finibus dignissim.',
        image: 'https://images.pexels.com/photos/874158/pexels-photo-874158.jpeg?auto=compress&cs=tinysrgb&h=300',
        date: '13 Aug 2018',
    },
    {
        name: 'Ainsley',
        desc: 'Fusce fermentum diam sed vulputate fringilla.',
        image: 'https://images.pexels.com/photos/324658/pexels-photo-324658.jpeg?auto=compress&cs=tinysrgb&h=300',
        date: '28 Jul 2018',
    },
    {
        name: 'Russell Crowe',
        desc: 'Mauris dolor magna, sodales et finibus nec, feugiat nec enim.',
        image: 'https://images.pexels.com/photos/894723/pexels-photo-894723.jpeg?auto=compress&cs=tinysrgb&h=300',
        date: '15 Jul 2018',
    },
    
]

export default Entry