import React from "react"

class ButtonDecrement extends React.Component {
    render() {
        return this.props.children || null
    }
}

export default ButtonDecrement