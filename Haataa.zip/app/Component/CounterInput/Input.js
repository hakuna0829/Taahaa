import React from "react"

class Input extends React.Component {
    render() {
        return this.props.children || null
    }
}

export default Input