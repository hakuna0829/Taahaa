import React from "react"

class ButtonIncrement extends React.Component {
    render() {
        return this.props.children || null
    }
}

export default ButtonIncrement